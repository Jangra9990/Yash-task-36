
import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Protected() {
    const [message, setMessage] = useState("");
    const [username, setUsername] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        const getProtectedData = async () => {
            const token = localStorage.getItem("token");

            if (!token) {
                navigate("/login");
                return;
            }

            try {
                const res = await axios.get(
                    "http://localhost:5000/protected",
                    {
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    }
                );

                setMessage(res.data.message);
                setUsername(res.data.user.username);
            } catch (error) {
                localStorage.removeItem("token");
                navigate("/login");
            }
        };

        getProtectedData();
    }, [navigate]);

    const handleLogout = () => {
        localStorage.removeItem("token");
        navigate("/login");
    };

    return (
        <div className="container">
            <h2>Protected Dashboard</h2>
            <h3>Welcome, {username}</h3>
            <p>{message}</p>

            <button onClick={handleLogout}>Logout</button>
        </div>
    );
}

export default Protected;
