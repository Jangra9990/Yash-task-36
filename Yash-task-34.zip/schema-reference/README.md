Schema Reference

Project Description

Schema Reference is a full-stack web application built using React.js, Node.js, Express.js, and MongoDB. It allows users to create users and posts and displays posts with their respective user information.

Features

Create a new user with name and email

Create a post with title and content

Select a user while creating a post

Display all posts with user name and email

MongoDB database integration using Mongoose

Technologies Used

Frontend: React.js, Axios, CSS

Backend: Node.js, Express.js

Database: MongoDB

ODM: Mongoose

Project Structure

backend

config

models

routes

server.js

frontend

src

App.jsx

App.css

index.css

Installation and Setup

Clone the repository

Install backend dependencies

cd backend
npm install

Start backend

npm run dev

Install frontend dependencies

cd frontend
npm install

Start frontend

npm run dev

The frontend runs on the Vite development server and the backend runs on port 5000.

Environment Variables

Create a .env file inside the backend folder and add your MongoDB connection string.

MONGO_URI=your_mongodb_connection_string
PORT=5000
Author 
Yash