import { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

function App() {
    const [users, setUsers] = useState([]);
    const [posts, setPosts] = useState([]);

    const [user, setUser] = useState({
        name: "",
        email: ""
    });

    const [post, setPost] = useState({
        title: "",
        content: "",
        user: ""
    });

    const fetchPosts = async () => {
        try {
            const res = await axios.get("http://localhost:5000/posts");
            setPosts(res.data);
        } catch (error) {
            console.log(error);
        }
    };

    const fetchUsers = async () => {
        try {
            const res = await axios.get("http://localhost:5000/users");
            setUsers(res.data);
        } catch (error) {
            console.log(error);
        }
    };

    useEffect(() => {
        fetchPosts();
        fetchUsers();
    }, []);

    const handleUser = async (e) => {
        e.preventDefault();

        try {
            await axios.post("http://localhost:5000/users", user);
            alert("User created successfully");

            setUser({ name: "", email: "" });
            fetchUsers();
        } catch (error) {
    console.log(error.response?.data || error.message);
    alert(error.response?.data?.message || error.message);
}
    };

    const handlePost = async (e) => {
        e.preventDefault();

        try {
            await axios.post("http://localhost:5000/posts", post);
            alert("Post created successfully");

            setPost({ title: "", content: "", user: "" });
            fetchPosts();
        } catch (error) {
            alert(error.response?.data?.message || "Error creating post");
        }
    };

    return (
        <div className="container">
            <h1>Schema Reference</h1>

            <div className="forms">
                <form onSubmit={handleUser}>
                    <h2>Create User</h2>

                    <input
                        type="text"
                        placeholder="Enter Name"
                        value={user.name}
                        onChange={(e) => setUser({ ...user, name: e.target.value })}
                        required
                    />

                    <input
                        type="email"
                        placeholder="Enter Email"
                        value={user.email}
                        onChange={(e) => setUser({ ...user, email: e.target.value })}
                        required
                    />

                    <button type="submit">Add User</button>
                </form>

                <form onSubmit={handlePost}>
                    <h2>Create Post</h2>

                    <input
                        type="text"
                        placeholder="Enter Title"
                        value={post.title}
                        onChange={(e) => setPost({ ...post, title: e.target.value })}
                        required
                    />

                    <textarea
                        placeholder="Enter Content"
                        value={post.content}
                        onChange={(e) => setPost({ ...post, content: e.target.value })}
                        required
                    />

                    <select
                        value={post.user}
                        onChange={(e) => setPost({ ...post, user: e.target.value })}
                        required
                    >
                        <option value="">Select User</option>
                        {users.map((u) => (
                            <option key={u._id} value={u._id}>
                                {u.name}
                            </option>
                        ))}
                    </select>

                    <button type="submit">Add Post</button>
                </form>
            </div>

            <div className="posts">
                <h2>All Posts</h2>

                {posts.map((p) => (
                    <div className="post-card" key={p._id}>
                        <h3>{p.title}</h3>
                        <p>{p.content}</p>
                        <p><strong>Author:</strong> {p.user?.name}</p>
                        <p><strong>Email:</strong> {p.user?.email}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default App;