
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");

const app = express();

app.use(cors());
app.use(express.json());

let users = [];

const SECRET_KEY = "mysecretkey";

app.get("/", (req, res) => {
    res.send("JWT Authentication Backend Running");
});

app.post("/register", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({
            message: "Username and password are required"
        });
    }

    const existingUser = users.find(
        (user) => user.username === username
    );

    if (existingUser) {
        return res.status(400).json({
            message: "User already exists"
        });
    }

    users.push({ username, password });

    res.status(201).json({
        message: "User registered successfully"
    });
});

app.post("/login", (req, res) => {
    const { username, password } = req.body;

    const user = users.find(
        (user) => user.username === username && user.password === password
    );

    if (!user) {
        return res.status(401).json({
            message: "Invalid username or password"
        });
    }

    const token = jwt.sign(
        { username: user.username },
        SECRET_KEY,
        { expiresIn: "1h" }
    );

    res.json({
        message: "Login successful",
        token
    });
});

const verifyToken = (req, res, next) => {
    const token = req.headers.authorization;

    if (!token) {
        return res.status(401).json({
            message: "Access denied. Token required"
        });
    }

    try {
        const decoded = jwt.verify(
            token.split(" ")[1],
            SECRET_KEY
        );

        req.user = decoded;
        next();

    } catch (error) {
        res.status(403).json({
            message: "Invalid or expired token"
        });
    }
};

app.get("/protected", verifyToken, (req, res) => {
    res.json({
        message: "Welcome! You accessed the protected route.",
        user: req.user
    });
});

app.listen(5000, () => {
    console.log("Server running on port 5000");
});
