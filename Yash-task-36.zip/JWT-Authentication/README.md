
JWT Authentication

This project implements user authentication using JSON Web Tokens (JWT) with an Express.js backend and React.js frontend.

Features

User registration with username and password

User login with credential validation

JWT token generation after successful login

JWT authentication middleware

Protected route access using a valid token

JWT token storage in local storage

Logout functionality

Technologies Used

React.js

Node.js

Express.js

JSON Web Token

Axios

React Router DOM

How to Run

Backend

Open the backend folder

Install dependencies using npm install

Start the server using node server.js

Backend runs on http://localhost:5000

Frontend

Open the frontend folder

Install dependencies using npm install

Start the application using npm run dev

Frontend runs on http://localhost:5173

API Routes

POST /register

POST /login

GET /protected

Author

Yash
